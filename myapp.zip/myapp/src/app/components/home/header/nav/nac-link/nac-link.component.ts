import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nac-link',
  templateUrl: './nac-link.component.html',
  styleUrls: ['./nac-link.component.css']
})
export class NacLinkComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
