import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hypermarket',
  templateUrl: './hypermarket.component.html',
  styleUrls: ['./hypermarket.component.css']
})
export class HypermarketComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
