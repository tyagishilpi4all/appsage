import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-market-link',
  templateUrl: './market-link.component.html',
  styleUrls: ['./market-link.component.css']
})
export class MarketLinkComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
