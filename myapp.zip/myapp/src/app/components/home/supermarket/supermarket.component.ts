import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-supermarket',
  templateUrl: './supermarket.component.html',
  styleUrls: ['./supermarket.component.css']
})
export class SupermarketComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
